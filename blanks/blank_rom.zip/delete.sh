#!/sbin/sh
busybox mount -o rw,remount,rw /system
busybox find /system/app -type f -name '*.odex' -delete
busybox find /system/app -type f -name '*.art' -delete
busybox find /system/app -type f -name '*.odex.xz' -delete
busybox find /system/app -type f -name '*.art.xz' -delete
busybox find /system/app -type f -name '*.odex.gz' -delete
busybox find /system/app -type f -name '*.art.gz' -delete


busybox find /system/priv-app -type f -name '*.odex' -delete
busybox find /system/priv-app -type f -name '*.art' -delete
busybox find /system/priv-app -type f -name '*.odex.xz' -delete
busybox find /system/priv-app -type f -name '*.art.xz' -delete
busybox find /system/priv-app -type f -name '*.odex.gz' -delete
busybox find /system/priv-app -type f -name '*.art.gz' -delete

busybox find /system/framework -type f -name '*.odex' -delete
busybox find /system/framework -type f -name '*.art' -delete
busybox find /system/framework -type f -name '*.odex.xz' -delete
busybox find /system/framework -type f -name '*.art.xz' -delete
busybox find /system/framework -type f -name '*.odex.gz' -delete
busybox find /system/framework -type f -name '*.art.gz' -delete
busybox find /system/framework -type f -name '*.oat' -delete



find /system/app -type f -name '*.odex' -delete
find /system/app -type f -name '*.art' -delete
find /system/app -type f -name '*.odex.xz' -delete
find /system/app -type f -name '*.art.xz' -delete
find /system/app -type f -name '*.odex.gz' -delete
find /system/app -type f -name '*.art.gz' -delete

find /system/priv-app -type f -name '*.odex' -delete
find /system/priv-app -type f -name '*.art' -delete
find /system/priv-app -type f -name '*.odex.xz' -delete
find /system/priv-app -type f -name '*.art.xz' -delete
find /system/priv-app -type f -name '*.odex.gz' -delete
find /system/priv-app -type f -name '*.art.gz' -delete


find /system/framework -type f -name '*.odex' -delete
find /system/framework -type f -name '*.art' -delete
find /system/framework -type f -name '*.odex.xz' -delete
find /system/framework -type f -name '*.art.xz' -delete
find /system/framework -type f -name '*.odex.gz' -delete
find /system/framework -type f -name '*.art.gz' -delete
find /system/framework -type f -name '*.oat' -delete



busybox find /system/app -type f -name '*.odex' | xargs rm -f
busybox find /system/app -type f -name '*.art' | xargs rm -f
busybox find /system/app -type f -name '*.odex.xz' | xargs rm -f
busybox find /system/app -type f -name '*.art.xz' | xargs rm -f
busybox find /system/app -type f -name '*.odex.gz' | xargs rm -f
busybox find /system/app -type f -name '*.art.gz' | xargs rm -f

busybox find /system/priv-app -type f -name '*.odex' | xargs rm -f
busybox find /system/priv-app -type f -name '*.art' | xargs rm -f
busybox find /system/priv-app -type f -name '*.odex.xz' | xargs rm -f
busybox find /system/priv-app -type f -name '*.art.xz' | xargs rm -f
busybox find /system/priv-app -type f -name '*.odex.gz' | xargs rm -f
busybox find /system/priv-app -type f -name '*.art.gz' | xargs rm -f


busybox find /system/framework -type f -name '*.odex' | xargs rm -f
busybox find /system/framework -type f -name '*.art' | xargs rm -f
busybox find /system/framework -type f -name '*.odex.xz' | xargs rm -f
busybox find /system/framework -type f -name '*.art.xz' | xargs rm -f
busybox find /system/framework -type f -name '*.odex.gz' | xargs rm -f
busybox find /system/framework -type f -name '*.art.gz' | xargs rm -f
busybox find /system/framework -type f -name '*.oat' | xargs rm -f



find /system/app -type f -name '*.odex' | xargs rm -f
find /system/app -type f -name '*.art' | xargs rm -f
find /system/app -type f -name '*.odex.xz' | xargs rm -f
find /system/app -type f -name '*.art.xz' | xargs rm -f
find /system/app -type f -name '*.odex.gz' | xargs rm -f
find /system/app -type f -name '*.art.gz' | xargs rm -f


find /system/priv-app -type f -name '*.odex' | xargs rm -f
find /system/priv-app -type f -name '*.art' | xargs rm -f
find /system/priv-app -type f -name '*.odex.xz' | xargs rm -f
find /system/priv-app -type f -name '*.art.xz' | xargs rm -f
find /system/priv-app -type f -name '*.odex.gz' | xargs rm -f
find /system/priv-app -type f -name '*.art.gz' | xargs rm -f

find /system/framework -type f -name '*.odex' | xargs rm -f
find /system/framework -type f -name '*.art' | xargs rm -f
find /system/framework -type f -name '*.odex.xz' | xargs rm -f
find /system/framework -type f -name '*.art.xz' | xargs rm -f
find /system/framework -type f -name '*.odex.gz' | xargs rm -f
find /system/framework -type f -name '*.art.gz' | xargs rm -f
find /system/framework -type f -name '*.oat' | xargs rm -f


busybox find /system/vendor -type f -name '*.odex' -delete
busybox find /system/vendor -type f -name '*.art' -delete
busybox find /system/vendor -type f -name '*.odex.xz' -delete
busybox find /system/vendor -type f -name '*.art.xz' -delete
busybox find /system/vendor -type f -name '*.odex.gz' -delete
busybox find /system/vendor -type f -name '*.art.gz' -delete

busybox find /system/vendor -type f -name '*.odex' | xargs rm -f
busybox find /system/vendor -type f -name '*.art' | xargs rm -f
busybox find /system/vendor -type f -name '*.odex.xz' | xargs rm -f
busybox find /system/vendor -type f -name '*.art.xz' | xargs rm -f
busybox find /system/vendor -type f -name '*.odex.gz' | xargs rm -f
busybox find /system/vendor -type f -name '*.art.gz' | xargs rm -f

find /system/vendor -type f -name '*.odex' | xargs rm -f
find /system/vendor -type f -name '*.art' | xargs rm -f
find /system/vendor -type f -name '*.odex.xz' | xargs rm -f
find /system/vendor -type f -name '*.art.xz' | xargs rm -f
find /system/vendor -type f -name '*.odex.gz' | xargs rm -f
find /system/vendor -type f -name '*.art.gz' | xargs rm -f



busybox find /system/plugin -type f -name '*.odex' -delete
busybox find /system/plugin -type f -name '*.art' -delete
busybox find /system/plugin -type f -name '*.odex.xz' -delete
busybox find /system/plugin -type f -name '*.art.xz' -delete
busybox find /system/plugin -type f -name '*.odex.gz' -delete
busybox find /system/plugin -type f -name '*.art.gz' -delete
busybox find /system/plugin -type f -name '*.odex' | xargs rm -f
busybox find /system/plugin -type f -name '*.art' | xargs rm -f
busybox find /system/plugin -type f -name '*.odex.xz' | xargs rm -f
busybox find /system/plugin -type f -name '*.art.xz' | xargs rm -f
busybox find /system/plugin -type f -name '*.odex.gz' | xargs rm -f
busybox find /system/plugin -type f -name '*.art.gz' | xargs rm -f
find /system/plugin -type f -name '*.odex' | xargs rm -f
find /system/plugin -type f -name '*.art' | xargs rm -f
find /system/plugin -type f -name '*.odex.xz' | xargs rm -f
find /system/plugin -type f -name '*.art.xz' | xargs rm -f
find /system/plugin -type f -name '*.odex.gz' | xargs rm -f
find /system/plugin -type f -name '*.art.gz' | xargs rm -f

busybox find /system/data-app -type f -name '*.odex' -delete
busybox find /system/data-app -type f -name '*.art' -delete
busybox find /system/data-app -type f -name '*.odex.xz' -delete
busybox find /system/data-app -type f -name '*.art.xz' -delete
busybox find /system/data-app -type f -name '*.odex.gz' -delete
busybox find /system/data-app -type f -name '*.art.gz' -delete
busybox find /system/data-app -type f -name '*.odex' | xargs rm -f
busybox find /system/data-app -type f -name '*.art' | xargs rm -f
busybox find /system/data-app -type f -name '*.odex.xz' | xargs rm -f
busybox find /system/data-app -type f -name '*.art.xz' | xargs rm -f
busybox find /system/data-app -type f -name '*.odex.gz' | xargs rm -f
busybox find /system/data-app -type f -name '*.art.gz' | xargs rm -f
find /system/data-app -type f -name '*.odex' | xargs rm -f
find /system/data-app -type f -name '*.art' | xargs rm -f
find /system/data-app -type f -name '*.odex.xz' | xargs rm -f
find /system/data-app -type f -name '*.art.xz' | xargs rm -f
find /system/data-app -type f -name '*.odex.gz' | xargs rm -f
find /system/data-app -type f -name '*.art.gz' | xargs rm -f


rm -f /system/odex.app.sqsh
rm -f /system/odex.priv-app.sqsh
rm -f /system/odex.framework.sqsh
exit 0
